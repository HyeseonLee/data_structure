package cse2010.homework2;

/*
 * © 2020 CSE2010 HW #2
 *
 * DO NOT MODIFY THIS CLASS!
 */
public class NoSuchTermExistsException extends RuntimeException {
    public NoSuchTermExistsException() {
    }

    public NoSuchTermExistsException(final String message) {
        super(message);
    }
}
